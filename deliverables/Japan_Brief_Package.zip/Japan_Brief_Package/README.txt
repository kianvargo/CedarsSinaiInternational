Japan country brief package

Japan_Summary_DRAFT.docx         Short visual summary (title page + about 4 pages)
Japan_Profile_DRAFT.docx         Full country profile
Japan_Profile_DRAFT_SOURCES.docx Numbered sources for both documents
Partnerships_Tracker.xlsx         Verified foreign health-system partnerships, all countries
Japan_partnerships_map.png       Partnerships by city (also inside both documents)

In Word, click Yes if asked to update fields: it fills in the table-of-contents page numbers.
